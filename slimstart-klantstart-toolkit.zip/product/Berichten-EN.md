# Client Onboarding Toolkit

Make a working copy of the Excel file and open Clients EN. Keep the blank original as your template.
Add one row per project. Record the contact, project, status, next action and follow-up date.
Filter by follow-up date. Tackle overdue actions first. These appear in pale red while the project remains open.
Pick a message from the following pages. Replace every bracketed field, add a greeting and sign-off, and check links and attachments.
After sending, update the status, last contact date and next action. Select Closed once aftercare is complete.

## 01 · Acknowledge an enquiry

Thanks for asking about [project]. I’ll review your request and get back to you by [date] with a next step.

## 02 · Clarify the brief

What would you like [project] to achieve, who is it for, and when would you like to start? Your answers will help me suggest an approach.

## 03 · Arrange a call

Could we talk through [topic]? I’m available at [option A] or [option B]. Which works for you?

## 04 · Confirm the call

We’re booked for [date] at [time and time zone] at [location or link]. We’ll cover [topic]. Could you share [document] beforehand?

## 05 · Recap the conversation

My understanding is that [goal] is your priority. We agreed I’d handle [action] by [date]. Have I captured that correctly?

## 06 · Send a quote

I’ve attached the quote for [project], including the scope, schedule and price. Does it cover what you need? Please let me know by [date].

## 07 · Check quote delivery

Did the quote for [project] reach you? I’m happy to resend it if the attachment is missing.

## 08 · Explore a concern

You mentioned [concern]. Would it help if I explained [item] or put together a revised option? Let me know which would be more useful.

## 09 · Close the quote loop

The quote for [project] is valid until [date]. Would you like to proceed, take more time or close the enquiry for now?

## 10 · Welcome a new client

I’m looking forward to working together on [project]. Our first step is [action]. I’ll be in touch on [date] to coordinate the start.

## 11 · Request materials

To start [item], I’ll need [materials]. Could you send them via [channel] by [date]? Let me know if you need more time.

## 12 · Confirm kickoff

I’ve received [materials] and will start on [date]. I’ll share the first version on [first draft date] via [channel].

## 13 · Share progress

[Item] is complete and I’m now working on [next step]. Could you confirm [decision] by [date]?

## 14 · Agree a scope change

You’d like to add [change]. This would change [price or schedule] to [revised proposal]. Could you confirm in writing before I schedule the work?

## 15 · Request feedback

The first version is ready at [link]. Could you collect your comments on [item] and send them over by [date]?

## 16 · Deliver the work

Here is the final version of [project]: [link]. Please open it and check [item to verify]. Could you confirm it arrived safely?

## 17 · Check in after delivery

How have you been getting on with [product] since delivery? If you’re stuck on [item], send me your question and I’ll take a look.

## 18 · Invite a review

Would you like to share your experience of [service]? You can describe how the project went in your own words at [review link]. Thank you for your time.

## 19 · Follow up on a review

If you’d still like to share your experience, here’s the review page: [review link]. Feel free to skip this if now isn’t a good time.

## 20 · Thank a reviewer

Thank you for taking the time to share your experience. I’ll keep your point about [detail] in mind on my next project.
