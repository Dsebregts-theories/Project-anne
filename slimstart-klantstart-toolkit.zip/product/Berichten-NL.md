# De Klantstart Toolkit

Maak een werkkopie van het Excel-bestand. Open Klanten NL. Houd het lege origineel als sjabloon.
Voeg per opdracht één regel toe. Vul contact, project, status, volgende actie en opvolgdatum in.
Filter op opvolgdatum en behandel eerst de verlopen acties. Die kleuren lichtrood zolang de opdracht openstaat.
Kies een bericht op de volgende pagina’s. Vervang alle velden tussen haken, voeg je aanhef en ondertekening toe en controleer links en bijlagen.
Werk na verzending de status, laatste contactdatum en volgende actie bij. Kies Afgerond zodra ook de nazorg klaar is.

## 01 · Ontvangst bevestigen

Bedankt voor je aanvraag over [project]. Ik bekijk je vraag en laat je uiterlijk [datum] weten wat ik voor je kan doen.

## 02 · Vraag verhelderen

Wat wil je met [project] bereiken, voor wie is het bedoeld en wanneer wil je starten? Met die drie antwoorden kan ik gericht meedenken.

## 03 · Kennismaking plannen

Zullen we [onderwerp] kort bespreken? Ik kan op [optie A] of [optie B]. Welk moment komt je uit?

## 04 · Gesprek bevestigen

Onze afspraak staat op [datum] om [tijd en tijdzone] via [locatie of link]. We bespreken [onderwerp]. Wil je vooraf [document] delen?

## 05 · Gesprek samenvatten

Ik heb genoteerd dat [doel] voor jou vooropstaat. We spraken af dat ik [actie] oppak vóór [datum]. Klopt dat zo?

## 06 · Offerte sturen

Hierbij de offerte voor [project]. Je vindt hierin de werkzaamheden, planning en prijs. Past het voorstel bij je wensen? Ik hoor graag van je vóór [datum].

## 07 · Ontvangst offerte checken

Is de offerte voor [project] goed aangekomen? Ik stuur hem graag opnieuw als de bijlage ontbreekt.

## 08 · Twijfel bespreken

Je noemde [vraagpunt]. Zal ik [onderdeel] verder toelichten of een aangepaste variant uitwerken? Laat me weten wat je helpt bij je keuze.

## 09 · Laatste offertecheck

De offerte voor [project] is geldig tot [datum]. Wil je verder, heb je meer tijd nodig of kan ik de aanvraag afsluiten?

## 10 · Opdracht verwelkomen

Fijn dat we samen aan [project] gaan werken. De eerste stap is [actie]. Ik neem op [datum] contact op om de start af te stemmen.

## 11 · Materiaal opvragen

Om [onderdeel] te starten heb ik [materiaal] nodig. Wil je dit vóór [datum] via [kanaal] aanleveren? Geef gerust aan als die datum lastig is.

## 12 · Start bevestigen

Ik heb [materiaal] ontvangen en start op [datum]. Je ontvangt de eerste versie op [datum eerste versie] via [kanaal].

## 13 · Voortgang delen

[Onderdeel] is afgerond. Nu werk ik aan [volgende stap]. Lukt het om [beslissing] vóór [datum] aan mij door te geven?

## 14 · Wijziging afstemmen

Je wilt [wijziging] toevoegen. Dat verandert [prijs of planning] in [nieuw voorstel]. Wil je dit schriftelijk bevestigen voordat ik het inplan?

## 15 · Feedback vragen

De eerste versie staat klaar via [link]. Wil je je opmerkingen over [onderdeel] bundelen en vóór [datum] terugsturen?

## 16 · Opleveren

Hier vind je de definitieve versie van [project]: [link]. Open het bestand en controleer [controlepunt]. Laat je weten of alles goed is aangekomen?

## 17 · Nazorg bieden

Hoe gaat het met [product] sinds de oplevering? Als je vastloopt bij [onderdeel], stuur me dan je vraag. Ik denk graag mee.

## 18 · Review vragen

Wil je je ervaring met [dienst] delen? Via [reviewlink] kun je in je eigen woorden vertellen hoe de samenwerking verliep. Alvast bedankt voor je tijd.

## 19 · Review herinneren

Mocht je nog een ervaring willen delen, dan vind je de reviewpagina hier: [reviewlink]. Voel je vrij dit bericht over te slaan als het nu niet uitkomt.

## 20 · Review bedanken

Bedankt dat je de tijd nam om je ervaring te delen. Je opmerking over [detail] neem ik mee naar mijn volgende project.
