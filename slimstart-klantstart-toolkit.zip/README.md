# SlimStart Studio · Klantstart Toolkit

Tweetalig product voor zzp’ers en kleine ondernemers die aanvragen, offertes en nazorg op één plek willen bijhouden. Beoogde verkoopprijs €39,95.

## Begin hier

| Onderdeel | Nederlands | English |
| --- | --- | --- |
| Snelstart en volledige handleiding | [PDF Nederlands](product/Handleiding-NL.pdf) | [English PDF](product/Handleiding-EN.pdf) |
| 20 bewerkbare klantberichten | [Berichten](product/Berichten-NL.md) | [Messages](product/Berichten-EN.md) |
| Klantenbestand | [Excel · tab Klanten NL](product/Klantenbestand.xlsx) | [Excel · Clients EN sheet](product/Klantenbestand.xlsx) |

Maak voor eigen gebruik een kopie van het Excel-sjabloon. Elk taalblad heeft ruimte voor 1.000 opdrachten. Voor klanten lever je de map `product` aan. In `verkoop` staan de [presentatie](verkoop/Productpresentatie.pptx) en [winkel- en socialmediakopie](verkoop/Verkoopteksten.md).

## Uploaden naar GitHub

1. Pak het ZIP-bestand lokaal uit.
2. Maak een lege repository aan, bijvoorbeeld `slimstart-klantstart-toolkit`. Kies **Private** als de betaalde inhoud alleen voor jou of je team toegankelijk moet zijn.
3. Open de bestandsupload in de repository. Sleep vanuit de uitgepakte map `README.md`, `product` en `verkoop` naar het uploadvenster.
4. Kies **Commit changes**. Controleer of deze leeswijzer op de startpagina verschijnt en open de links in de tabel.
