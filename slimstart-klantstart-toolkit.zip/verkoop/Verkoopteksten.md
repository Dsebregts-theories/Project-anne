# De Klantstart Toolkit · €39,95

## Productpagina
Een offerte verstuurd en daarna niets meer gehoord? Met de Klantstart Toolkit zie je in Excel welke klant op een reactie wacht. Kies een van de twintig berichten, pas de tekst aan en plan je volgende contactmoment. Gemaakt voor zzp’ers en kleine ondernemers die hun klantcontact zelf regelen.

Je ontvangt twee PDF-handleidingen, twintig kopieerbare berichten in zowel Nederlands als Engels en een Excel-klantenbestand met statuskeuzes, datumfilters en markering van verlopen acties. Direct te gebruiken voor aanvragen, offerteopvolging, oplevering en reviewverzoeken.

**Knoptekst** · Download de Klantstart Toolkit

## Kort bericht voor sociale media
Welke offerte verdient vandaag een belletje? Zet je opvolgdatum in Excel en gebruik een passend bericht uit de Klantstart Toolkit. Twintig berichten, van eerste aanvraag tot review, in Nederlands én Engels. €39,95.

# Client Onboarding Toolkit · €39.95

## Product listing
Sent a quote and heard nothing back? Open the Excel tracker to see who is due a reply. Pick one of twenty messages, personalise it and schedule your next follow-up. Designed for freelancers and small businesses managing their own client relationships.

Includes two PDF guides, twenty copy-ready messages in both Dutch and English, and an Excel tracker with status dropdowns, date filters and overdue highlighting. Use it for enquiries, quote follow-ups, delivery and review requests.

**Button text** · Download the Client Onboarding Toolkit

## Social post
Which quote needs a follow-up today? Set a date in the Excel tracker and pick a message from the Client Onboarding Toolkit. Twenty messages take you from enquiry to review, in Dutch and English. €39.95.
